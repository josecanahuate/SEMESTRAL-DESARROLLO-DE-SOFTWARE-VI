package com.videorecord.movavi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.TextView;

import com.videorecord.movavi.MainActivity;

public class Contrasena_olvido extends AppCompatActivity {
    TextView linksesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrasena_olvido);

        linksesion = findViewById(R.id.linksesion);
        SpannableString spannableString2 = new SpannableString("Inicia sesión");
        ClickableSpan span2 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {

            }
        };
        spannableString2.setSpan(span2, 0, 13, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
        linksesion.setText(spannableString2);
        linksesion.setMovementMethod(LinkMovementMethod.getInstance());

        linksesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Contrasena_olvido.this, MainActivity.class);
                startActivity(intent);
            }
        });





    }
}