package com.videorecord.movavi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.VideoView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.IOException;

public class Movavi_Video extends AppCompatActivity {

    ImageButton btnrecord;
    ImageButton btncamara;
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    MenuItem salir_app;
    ImageView imageView6;

    private static int CAMERA_PERMISSION_CODE = 100;
    private static int VIDEO_RECORD_CODE = 101;
    private static int IMAGE_CAPTURE_CODE = 102;
    private Uri videoPath;
    private String currentPhotoPath;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movavi_video);
        btnrecord = findViewById(R.id.btnrecord);
        btncamara = findViewById(R.id.btncamara);
        imageView6 = findViewById(R.id.imageView6);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this, gso);

        //DATOS PARA MOSTRAR DE CUENTA DE GOOGLE
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if(acct!= null){
            String personName = acct.getDisplayName();
            String personEmail = acct.getEmail();
            //en name y email,  iria el txtview asignado a nombre y a email.
            // name.setText(personName);
            // email.setText(personEmail);
        }

        findViewById(R.id.btncamara).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fileName = "photo";
                File storageDirectory = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                try {
                    File imageFile = File.createTempFile(fileName, ".jpg", storageDirectory);
                    currentPhotoPath = imageFile.getAbsolutePath();

                    Uri imageUri = FileProvider.getUriForFile(Movavi_Video.this, "com.videorecord.movavi.fileprovider", imageFile);
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri );
                    startActivityForResult(intent, 102 );

                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });


        if (isCameraPresentInPhone()){
            Log.i("VIDEO_RECORD_TAG", "Camara detectada");
            getCameraPermission();
        }
        else{
            Log.i("VIDEO_RECORD_TAG", "Camara no detectada");
        }
    }

    public void recordVideoButtonPressed(View view){
        recordVideo();
    }

    private boolean isCameraPresentInPhone(){
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)){
            return true;
        }
        else{
            return false;
        }
    }

    private void getCameraPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED); {

            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CAMERA},CAMERA_PERMISSION_CODE);
        }

    }
    private void recordVideo(){
        Intent intent  = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, VIDEO_RECORD_CODE);
        //ESTA LINEA DE ABAJO LIMITA EL VIDEO A 10 SEGUNDOS
        // intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == 102) {
            Bitmap bitmap = BitmapFactory.decodeFile(currentPhotoPath);
            ImageView imageView6 = findViewById(R.id.imageView6);
            imageView6.setImageBitmap(bitmap);
        }
        else if (resultCode == RESULT_OK && requestCode == 101) {
            videoPath = data.getData();

            //MUESTRA EL VIDEO
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            VideoView videoView = new VideoView(this);
            videoView.setVideoURI(data.getData());
            videoView.start();
            builder.setView(videoView).show();
            Log.i("VIDEO_RECORD_TAG", "El video está grabado y disponible en la galería" + videoPath);
        }
        else if (resultCode == RESULT_CANCELED){
            Log.i("VIDEO_RECORD_TAG", "La grabacion del video se ha cancelado" + videoPath);
        }
        else {
            Log.i("VIDEO_RECORD_TAG", "Error 70: Fallo de Video." + videoPath);
        }
    }


    //CONFIGURACION MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.salir_app:
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                // se Configura el titulo.
                builder.setTitle("Movavi Video");
                // se Configura el mensaje
                builder.setMessage("¿Quieres cerrar la app?");
                // se coloca false porque debe elegir una opcion obligatoriamente
                builder.setCancelable(false)
                        .setPositiveButton("Aceptar",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finishAffinity();
                            }
                        })
                        .setNegativeButton("Cancelar",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();
                            }
                        }).create().show();
                break;

            case R.id.perfil:
                Intent intent = new Intent(Movavi_Video.this, basedatos.class);
                startActivity(intent);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }




}





