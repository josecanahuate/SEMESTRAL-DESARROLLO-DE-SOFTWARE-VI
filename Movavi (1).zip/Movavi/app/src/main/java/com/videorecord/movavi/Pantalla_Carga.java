package com.videorecord.movavi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.VideoView;

import com.videorecord.movavi.MainActivity;

public class Pantalla_Carga extends AppCompatActivity {

    private static int CAMERA_PERMISSION_CODE = 100;
    private static int VIDEO_RECORD_CODE = 101;
    private Uri videoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_carga);

        int Tiempo = 1000;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Pantalla_Carga.this, MainActivity.class));
                finish();
            }
        }, Tiempo);
    }

    private void recordVideo(){
        Intent intent  = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, VIDEO_RECORD_CODE);
        //ESTA LINEA DE ABAJO LIMITA EL VIDEO A 10 SEGUNDOS
        // intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
    }

    public void recordVideoButtonPressed(View view){
        recordVideo();
    }

}