package com.videorecord.movavi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class Registro_page extends AppCompatActivity {
    TextView usnombre,usemail,uspassword,uspassword1;
    ImageButton btnreg;
    Button btnfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_page);

        usnombre=findViewById(R.id.usnombre);
        usemail=findViewById(R.id.usemail);
        uspassword=findViewById(R.id.uspassword);
        btnreg=findViewById(R.id.btnreg);
        uspassword1=findViewById(R.id.uspassword1);
        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Usuario obj = new Usuario(Registro_page.this);
                obj.setnombre(usnombre.getText().toString());
                obj.setcorreo(usemail.getText().toString());
                obj.setpassword(uspassword.getText().toString());
                if (obj.insertar())
                {
                    Util.muestra_dialogo( Registro_page.this,"Se ha isnertado el usuario");
                    usnombre.setText("");
                    usemail.setText("");
                    uspassword.setText("");
                    uspassword1.setText("");
                    startActivity(new Intent(Registro_page.this, MainActivity.class));
                    finish();


                }


            }
        });



        }
}