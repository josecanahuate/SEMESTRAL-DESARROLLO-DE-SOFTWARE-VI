package com.videorecord.movavi;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class Usuario {
    private int id;
    private String nombre;
    private String correo;
    private String password;
    mihelpersqllite admin;
    SQLiteDatabase db;
    String BaseDatos = "basededatos.db";

    public Usuario() {
    }

    public Usuario(Activity activity1) {
        admin = new mihelpersqllite(activity1, BaseDatos, null, 1);
        db = admin.getWritableDatabase();
    }

    public Usuario(int id, String nombre, String correo, String password) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.password = password;
    }

    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    public String getcorreo() {
        return correo;
    }

    public void setcorreo(String correo) {
        this.correo = correo;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }

    public boolean insertar() {
        ContentValues registro = new ContentValues();
        registro.put("nombre", this.nombre);
        registro.put("correo", this.correo);
        registro.put("password", Util.cifrar(this.password));
        db.insert("usuario", null, registro);
        db.close();
        return true;
    }

    public boolean modificar() {
        ContentValues registro = new ContentValues();
        registro.put("nombre", this.nombre);
        registro.put("correo", this.correo);
        registro.put("password", Util.cifrar(this.password));
        db.update("usuario", registro, "id=" + this.id, null);
        db.close();
        return true;
    }

    public boolean eliminar() {
        db.delete("usuario", "id=" + this.id, null);
        db.close();
        return true;
    }

    public ArrayList<Usuario> ListarTodos() {
        ArrayList<Usuario> lista = new ArrayList<>();
        Cursor cursor = db.rawQuery("select id, nombre, correo, password from usuario", null);
        while (cursor.moveToNext()) {
            Usuario o = new Usuario();
            o.id = cursor.getInt(0);
            o.nombre = cursor.getString(1);
            o.correo = cursor.getString(2);
            o.password = cursor.getString(3);

            lista.add(o);
        }
        db.close();
        return lista;
    }

    public boolean buscar() {
        return true;
    }


    public boolean limpia(){


        return  true;
    }


    public boolean verificar_usuario() {

        String query = "select id,nombre,correo,password from usuario where  nombre = '" + this.nombre + "' and password='" + Util.cifrar(this.password) + "'";
        db = admin.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToNext()) {
            db.close();
            return true;
        }
        db.close();
        return false;
    }

}

