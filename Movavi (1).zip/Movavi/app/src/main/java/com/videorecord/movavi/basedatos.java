package com.videorecord.movavi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class basedatos extends AppCompatActivity {

    TextView txtuserid;
    EditText txtuser,txtnomb,txtpass;
    Button btnadd,btnile;
    ListView lista_usuarios;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basedatos);

        btnadd = findViewById(R.id.btnadd);

        txtuserid = findViewById(R.id.txtuserid);
        txtnomb = findViewById(R.id.txtnomb);
        txtpass = findViewById(R.id.txtpass);
        txtuser = findViewById(R.id.txtuser);
        lista_usuarios = findViewById(R.id.lista_usuarios);

        muestra_todos();

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Usuario obj = new Usuario(basedatos.this);
                obj.setnombre(txtnomb.getText().toString());
                obj.setcorreo(txtuser.getText().toString());
                obj.setpassword(txtpass.getText().toString());
                if (txtuserid.getText().toString().trim().equals("")){
                    if (obj.insertar())
                    {
                        Util.muestra_dialogo( basedatos.this,"Se ha isnertado el usuario");
                        muestra_todos();
                        limpia();
                    }
                }else {
                    obj.setid( Integer.parseInt(txtuserid.getText().toString()));

                    if(obj.modificar())
                    {
                        Util.muestra_dialogo( basedatos.this,"Se ha modificado el usuario");
                        muestra_todos();
                        limpia();
                    }
                }

            }
        });


    }


    public void muestra_todos(){
        Usuario ojb = new Usuario(basedatos.this);
        ArrayList<Usuario> usuarios = ojb.ListarTodos();

        listado_usuarios adapter = new listado_usuarios(this, usuarios);
        lista_usuarios.setAdapter(adapter);
        lista_usuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //------------------>>>>>>> AQUI
                txtuserid.setText(""+usuarios.get(i).getid());
                txtnomb.setText(usuarios.get(i).getnombre());
                txtuser.setText(usuarios.get(i).getcorreo());
                txtpass.setText(usuarios.get(i).getpassword());
            }
        });


        lista_usuarios.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(basedatos.this);
                builder.setMessage("Esta seguro que desea eliminarlo");
                builder.setPositiveButton("SI", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        int posicion=(int)l;
                        Usuario obj = new Usuario(basedatos.this);
                        obj.setid(usuarios.get(posicion).getid());
                        if (obj.eliminar()) {
                            Util.muestra_dialogo( basedatos.this, "Se ha eliminado el usuario");
                            muestra_todos();
                            limpia();
                        }

                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.show();
                return false;
            }
        });

    }



    public void limpia(){
        txtnomb.setText("");
        txtuserid.setText("");
        txtpass.setText("");
        txtuser.setText("");
    }
    }
