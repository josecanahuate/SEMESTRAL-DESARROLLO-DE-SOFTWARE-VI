package com.videorecord.movavi;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class listado_usuarios extends BaseAdapter {
    protected Activity actividad;
    protected ArrayList<Usuario> items;

    public listado_usuarios(Activity actividad, ArrayList<Usuario> items) {
        this.actividad = actividad;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v =view;
        LayoutInflater inf = (LayoutInflater) actividad.getSystemService(Context.LAYOUT_INFLATER_SERVICE );
        v = inf.inflate(R.layout.activity_listado_usuarios, null);

        Usuario obj =  items.get(i);

        TextView lblid = v.findViewById(R.id.lblid);
        TextView lblcorreo = v.findViewById(R.id.lblcorreo);
        TextView lblPassword = v.findViewById(R.id.lblpassword);
        TextView lblNombre = v.findViewById(R.id.lblnombre);

        lblid.setText("" + obj.getid());
        lblNombre.setText(obj.getnombre());
        lblcorreo.setText(obj.getcorreo());
        lblPassword.setText(obj.getpassword());

        return v;
    }
}
